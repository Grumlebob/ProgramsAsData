void main()
{
 int e2;
 int e3;
 e2 = 5;
 e3 = 7;

 1 < 5 ? print e2 : print e3;
}