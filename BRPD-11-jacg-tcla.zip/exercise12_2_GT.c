// micro-C example 12 -- tail calls

int main() {
  if (22 > 11) print 33;
}
