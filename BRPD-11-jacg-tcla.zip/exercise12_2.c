// micro-C example 12 -- tail calls

int main() {
  if (11 <=22) print 33;
}
