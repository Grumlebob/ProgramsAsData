
int main() {
    if (1 && 0 || 5) print 33;
}