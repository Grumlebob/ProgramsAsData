/*

 */


void main(int maini)
{
 int e;
 e = 10;
 --e;
 print e;
 ++e;
 print e;
}